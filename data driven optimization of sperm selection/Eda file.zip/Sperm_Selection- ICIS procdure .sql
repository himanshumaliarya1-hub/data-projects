create database EDA ;
use  EDA;
CREATE TABLE sperm_selection (
    Record_ID VARCHAR(50),
    Patient_ID VARCHAR(50),
    Embryologist_ID VARCHAR(50),
    Selection_Date VARCHAR(50),
    Cycle_Number VARCHAR(50),

    Sperm_Concentration_M_per_ml VARCHAR(50),
    Total_Motility_Percent VARCHAR(50),
    Progressive_Motility_Percent VARCHAR(50),
    Normal_Morphology_Percent VARCHAR(50),

    Head_Shape_Score VARCHAR(50),
    Acrosome_Status VARCHAR(50),
    Midpiece_Assessment VARCHAR(50),
    Tail_Assessment VARCHAR(50),
    Motility_Pattern VARCHAR(50),
    Vacuoles_Present VARCHAR(50),

    Selection_Time_Seconds VARCHAR(50),
    Lab_Temperature_C VARCHAR(50),
    Lab_Humidity_Percent VARCHAR(50),

    Microscope_Type VARCHAR(50),
    Magnification_Used VARCHAR(50),

    Embryologist_Experience_Years VARCHAR(50),

    Fertilization_Success VARCHAR(10),
    Usable_Embryo VARCHAR(10),

    Day3_Grade VARCHAR(50),
    Day5_Blastocyst_Grade VARCHAR(50),

    Extra_Column VARCHAR(255)   -- 👈 absorbs extra data safely
);

ALTER TABLE sperm_selection DROP COLUMN Extra_Column;

ALTER TABLE sperm_selection
ADD COLUMN Selection_Date_Clean DATE;

UPDATE sperm_selection
SET Selection_Date = STR_TO_DATE(Selection_Date, '%d-%m-%Y');
drop table sperm_selection;

SET GLOBAL local_infile = 1;
LOAD DATA LOCAL INFILE
'C:/ProgramData/MySQL/MySQL Server 9.5/Uploads/Sperm_Selection_Dataset_DA.csv'
INTO TABLE sperm_selection
FIELDS TERMINATED BY ','
OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

select*from sperm_selection;

SELECT COUNT(*) AS total_records FROM sperm_selection;
SELECT * FROM sperm_selection LIMIT 10;

SELECT
    SUM(Patient_ID IS NULL) AS missing_patient,
    SUM(Midpiece_Assessment IS NULL) AS missing_midpiece,
    SUM(Tail_Assessment IS NULL) AS missing_tail,
    SUM(Vacuoles_Present IS NULL) AS missing_vacuoles,
    SUM(Day3_Grade IS NULL) AS missing_day3,
    SUM(Day5_Blastocyst_Grade IS NULL) AS missing_day5
FROM sperm_selection;

SELECT Record_ID, COUNT(*) AS duplicate_count
FROM sperm_selection
GROUP BY Record_ID
HAVING COUNT(*) > 1;
SELECT
    ROUND(AVG(Sperm_Concentration_M_per_ml),2) AS avg_concentration,
    ROUND(MIN(Sperm_Concentration_M_per_ml),2) AS min_concentration,
    ROUND(MAX(Sperm_Concentration_M_per_ml),2) AS max_concentration,

    ROUND(AVG(Total_Motility_Percent),2) AS avg_motility,
    ROUND(AVG(Progressive_Motility_Percent),2) AS avg_progressive,

    ROUND(AVG(Selection_Time_Seconds),2) AS avg_selection_time
FROM sperm_selection;
--  Motility Pattern  --
SELECT Motility_Pattern, COUNT(*) AS count
FROM sperm_selection
GROUP BY Motility_Pattern
ORDER BY count DESC;

-- Microscope usage --
SELECT Microscope_Type, COUNT(*) AS usage_count
FROM sperm_selection
GROUP BY Microscope_Type;

-- TARGET VARIABLE ANALYSIS --
-- Fertilization success rate --

SELECT
    ROUND(AVG(Fertilization_Success)*100,2) AS fertilization_rate_percent
FROM sperm_selection;

SELECT
    ROUND(AVG(Usable_Embryo)*100,2) AS usable_embryo_rate_percent
FROM sperm_selection;

-- Sperm quality vs fertilization --
SELECT
    Fertilization_Success,
    ROUND(AVG(Sperm_Concentration_M_per_ml),2) AS avg_concentration,
    ROUND(AVG(Total_Motility_Percent),2) AS avg_motility,
    ROUND(AVG(Normal_Morphology_Percent),2) AS avg_morphology
FROM sperm_selection
GROUP BY Fertilization_Success;

-- Embryologist Performance--
SELECT
    Embryologist_ID,
    COUNT(*) AS total_cases,
    ROUND(AVG(Fertilization_Success)*100,2) AS success_rate,
    ROUND(AVG(Selection_Time_Seconds),2) AS avg_time
FROM sperm_selection
GROUP BY Embryologist_ID
ORDER BY success_rate DESC;

-- Lab Conditions Analysis --
SELECT
    CASE
        WHEN Lab_Temperature_C BETWEEN 36.5 AND 37.5
         AND Lab_Humidity_Percent BETWEEN 40 AND 60
        THEN 'Optimal'
        ELSE 'Suboptimal'
    END AS lab_condition,
    ROUND(AVG(Fertilization_Success)*100,2) AS success_rate
FROM sperm_selection
GROUP BY lab_condition;

-- Temporal Analysis --
SELECT
    YEAR(Selection_Date) AS year,
    MONTH(Selection_Date) AS month,
    COUNT(*) AS procedures,
    ROUND(AVG(Fertilization_Success)*100,2) AS success_rate
FROM sperm_selection
GROUP BY year, month
ORDER BY year, month;

 


