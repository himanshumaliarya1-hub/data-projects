# -*- coding: utf-8 -*-
"""
Created on Sat Jan 24 12:24:23 2026

@author: Himanshu
"""

print("Data Driven Optimization of Sperm Selection Efficiency")
print('Start a EDA')


import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv(r"D:\numpy\Sperm_Selection_Dataset_DA.csv")

print('Data preprocessing')
df.head()
df.tail()
df.shape
df.info()

print('check the duplicated')

df.duplicated()
print(df.duplicated().sum())

print('Check the null')
print(df.isnull().sum())

df.isnull().sum().sort_values(ascending=False)

print('check the data type')
df.dtypes

df['Selection_Date']=pd.to_datetime(df['Selection_Date'])
df[['Fertilization_Success', 'Usable_Embryo']].value_counts()

print("""Check the missing values
Missing Values - Midpiece Assessment
Missing Values - Tail Assessment
Missing Values - Magnification Used
""")


df['Midpiece_Assessment'].fillna('Not_Assessed')
df['Tail_Assessment']=df['Tail_Assessment'].fillna('Unknown')
df['Magnification_Used']= df['Magnification_Used'].fillna('Not_Documented')

print('check the formatting')
df['Embryologist_ID'].str.upper()
df['Patient_ID'] = df['Patient_ID'].apply(
    lambda x: x if x.startswith('PT-') else 'PT-' + x
)

print('check the Range')


df.loc[df['Normal_Morphology_Percent'] >30,'Normal_Morphology_Percent' ]= np.nan

df.loc[df['Selection_Time_Seconds'] < 45,'Selection_Time_Seconds']= np.nan

print('Logical Integrity Errors')

df.loc[
    (df['Fertilization_Success'] == 0) & (df['Day3_Grade'].notna()),
    'Day3_Grade'
] = np.nan

df.drop_duplicates( subset=['Patient_ID', 'Oocyte_ID', 'Selection_Date'])

df['Head_Shape_Score'] = df['Head_Shape_Score'].str.title()

df['Motility_Pattern'] = df['Motility_Pattern'].replace(
    {'Progresive': 'Progressive'})

print('check the date&time')
df['Selection_Date'] = pd.to_datetime(df['Selection_Date'], errors='coerce')
today = pd.Timestamp.today()
df.loc[df['Selection_Date'] > today, 'Selection_Date'] = np.nan


df.isnull().sum()
df.describe()




