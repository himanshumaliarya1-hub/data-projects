# -*- coding: utf-8 -*-
"""
Created on Sat Feb  7 15:26:18 2026

@author: Himanshu
Date: February 2026
Sperm Selection Dataset - ICSI Procedures
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')


# Configuration
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_rows', 100)
sns.set_style('whitegrid')
plt.rcParams['figure.figsize'] = (14, 8)
plt.rcParams['font.size'] = 10

import os
os.makedirs('eda_output', exist_ok=True)
os.makedirs('eda_output/plots', exist_ok=True)

file_path = r"D:\file\Sperm_Selection_Dataset_DA.xlsx"
df = pd.read_excel(file_path, sheet_name='ICSI_Data')
data_dict = pd.read_excel(file_path, sheet_name='Data_Dictionary')
errors = pd.read_excel(file_path, sheet_name='Error_Summary')
outcomes = pd.read_excel(file_path, sheet_name='Clinical_Outcomes')
performance = pd.read_excel(file_path, sheet_name='Embryologist_Performance')


# Missing values analysis
print("\n--- Missing Values Analysis ---")
print("\n--- Missing Values Analysis ---")
missing_data = pd.DataFrame({
    'Column': df.columns,
    'Missing_Count': df.isnull().sum().values,
    'Missing_Percentage': (df.isnull().sum().values / len(df) * 100).round(2),
    'Data_Type': df.dtypes.values
})
missing_data = missing_data[missing_data['Missing_Count'] > 0].sort_values(
    'Missing_Percentage', ascending=False
)
print(missing_data.to_string(index=False))


duplicates = df.duplicated().sum()
print(f"\n--- Duplicate Records ---")
print(f"Total duplicates: {duplicates}")


# Convert date column
df['Selection_Date'] = pd.to_datetime(df['Selection_Date'])

# Future dates
future_dates = df[df['Selection_Date'] > datetime.now()]
print(f"1. Future dates: {len(future_dates)} records")

id_patterns = df['Patient_ID'].str.extract(r'^([A-Z]+-?)')[0].value_counts()
print(f"\n2. Patient ID patterns:")
print(id_patterns)

# Lab conditions out of range
temp_out = df[(df['Lab_Temperature_C'] < 36.5) | (df['Lab_Temperature_C'] > 37.5)]
humidity_out = df[(df['Lab_Humidity_Percent'] < 40) | (df['Lab_Humidity_Percent'] > 60)]
print(f"\n3. Lab conditions:")
temp_out = df[(df['Lab_Temperature_C'] < 36.5) | (df['Lab_Temperature_C'] > 37.5)]
humidity_out = df[(df['Lab_Humidity_Percent'] < 40) | (df['Lab_Humidity_Percent'] > 60)]

# Save data quality report
quality_report = {
    'Total_Records': len(df),
    'Duplicate_Records': duplicates,
    'Future_Dates': len(future_dates),
    'Temperature_Outliers': len(temp_out),
    'Humidity_Outliers': len(humidity_out),
    'Missing_Midpiece': df['Midpiece_Assessment'].isnull().sum(),
    'Missing_Tail': df['Tail_Assessment'].isnull().sum(),
    'Missing_Vacuoles': df['Vacuoles_Present'].isnull().sum(),
    'Missing_Day3': df['Day3_Grade'].isnull().sum(),
    'Missing_Day5': df['Day5_Blastocyst_Grade'].isnull().sum()
}
pd.DataFrame([quality_report]).to_csv('eda_output/data_quality_report.csv', index=False)


# SECTION 3: UNIVARIATE ANALYSIS 
print("SECTION 3: UNIVARIATE ANALYSIS - NUMERICAL VARIABLES")

numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
print(f"\nNumerical variables: {len(numerical_cols)}")

# Descriptive statistics
print("\n--- Descriptive Statistics ---")
desc_stats = df[numerical_cols].describe()
print(desc_stats)


print("="*50)
print('Save detailed statistics')
print("="*50)

desc_stats.to_csv('eda_output/descriptive_statistics.csv')

# Distribution plots for key continuous variables
key_continuous = [
    'Sperm_Concentration_M_per_ml',
    'Total_Motility_Percent',
    'Progressive_Motility_Percent',
    'Normal_Morphology_Percent',
    'Selection_Time_Seconds',
    'Lab_Temperature_C',
    'Lab_Humidity_Percent',
    'Embryologist_Experience_Years'
]

fig, axes = plt.subplots(4, 2, figsize=(16, 18))
axes = axes.flatten()

for idx, col in enumerate(key_continuous):
    # Histogram with KDE
    axes[idx].hist(df[col].dropna(), bins=30, color='steelblue', 
                   alpha=0.7, edgecolor='black', density=True)
    
    # Add KDE curve
    df[col].dropna().plot(kind='kde', ax=axes[idx], color='red', linewidth=2)
    
    axes[idx].set_title(f'Distribution of {col}', fontweight='bold', fontsize=11)
    axes[idx].set_xlabel(col)
    axes[idx].set_ylabel('Density')
    axes[idx].grid(True, alpha=0.3)
    
    # Add statistics text
    mean_val = df[col].mean()
    median_val = df[col].median()
    std_val = df[col].std()
    
    stats_text = f'Mean: {mean_val:.2f}\nMedian: {median_val:.2f}\nStd: {std_val:.2f}'
    axes[idx].text(0.02, 0.98, stats_text, transform=axes[idx].transAxes,
                   verticalalignment='top', bbox=dict(boxstyle='round', 
                   facecolor='wheat', alpha=0.5), fontsize=9)

plt.tight_layout()
plt.savefig('eda_output/plots/01_distributions_numerical.png', dpi=300, bbox_inches='tight')
print("\n✓ Saved: eda_output/plots/01_distributions_numerical.png")

# Box plots to identify outliers
fig, axes = plt.subplots(2, 4, figsize=(18, 10))
axes = axes.flatten()

for idx, col in enumerate(key_continuous):
    bp = axes[idx].boxplot(df[col].dropna(), vert=True, patch_artist=True)
    for patch in bp['boxes']:
        patch.set_facecolor('lightblue')
    
    axes[idx].set_title(f'Box Plot: {col}', fontweight='bold')
    axes[idx].set_ylabel(col)
    axes[idx].grid(True, alpha=0.3)
    
    # Calculate outliers
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    outliers = df[(df[col] < Q1 - 1.5*IQR) | (df[col] > Q3 + 1.5*IQR)][col]
    
    axes[idx].text(0.5, 0.02, f'Outliers: {len(outliers)}', 
                   transform=axes[idx].transAxes, ha='center',
                   bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.5))

plt.tight_layout()
plt.savefig('eda_output/plots/02_boxplots_outliers.png', dpi=300, bbox_inches='tight')
print("✓ Saved: eda_output/plots/02_boxplots_outliers.png")


print("\n" + "="*80)
print("SECTION 4: UNIVARIATE ANALYSIS - CATEGORICAL VARIABLES")
print("="*80)

categorical_cols = [
    'Head_Shape_Score',
    'Acrosome_Status',
    'Midpiece_Assessment',
    'Tail_Assessment',
    'Motility_Pattern',
    'Vacuoles_Present',
    'Microscope_Type',
    'Magnification_Used'
]

print("\n--- Categorical Variable Frequencies ---")
for col in categorical_cols:
    print(f"\n{col}:")
    freq = df[col].value_counts(dropna=False)
    freq_pct = df[col].value_counts(normalize=True, dropna=False) * 100
    freq_df = pd.DataFrame({
        'Value': freq.index,
        'Count': freq.values,
        'Percentage': freq_pct.values.round(2)
    })
    print(freq_df.to_string(index=False))

# Visualize categorical distributions
fig, axes = plt.subplots(3, 3, figsize=(18, 14))
axes = axes.flatten()

for idx, col in enumerate(categorical_cols):
    if idx < len(axes):
        value_counts = df[col].value_counts()
        colors = plt.cm.Set3(range(len(value_counts)))
        
        axes[idx].bar(range(len(value_counts)), value_counts.values, color=colors)
        axes[idx].set_title(f'{col}', fontweight='bold', fontsize=11)
        axes[idx].set_xticks(range(len(value_counts)))
        axes[idx].set_xticklabels(value_counts.index, rotation=45, ha='right')
        axes[idx].set_ylabel('Frequency')
        axes[idx].grid(True, axis='y', alpha=0.3)
        
        # Add value labels on bars
        for i, v in enumerate(value_counts.values):
            axes[idx].text(i, v, str(v), ha='center', va='bottom', fontweight='bold')

# Remove extra subplot
if len(categorical_cols) < len(axes):
    fig.delaxes(axes[-1])

plt.tight_layout()
plt.savefig('eda_output/plots/03_categorical_distributions.png', dpi=300, bbox_inches='tight')
print("\n✓ Saved: eda_output/plots/03_categorical_distributions.png")


print("\n" + "="*80)
print("SECTION 5: TARGET VARIABLE ANALYSIS")
print("="*80)

# Fertilization Success
print("\n--- Fertilization Success ---")
fert_counts = df['Fertilization_Success'].value_counts()
fert_rate = (df['Fertilization_Success'].sum() / len(df)) * 100
print(f"Success: {fert_counts.get(1, 0)} ({fert_rate:.2f}%)")
print(f"Failure: {fert_counts.get(0, 0)} ({100-fert_rate:.2f}%)")

# Usable Embryo
print("\n--- Usable Embryo ---")
embryo_counts = df['Usable_Embryo'].value_counts()
embryo_rate = (df['Usable_Embryo'].sum() / len(df)) * 100
print(f"Usable: {embryo_counts.get(1, 0)} ({embryo_rate:.2f}%)")
print(f"Not Usable: {embryo_counts.get(0, 0)} ({100-embryo_rate:.2f}%)")

# Day 3 Grade
print("\n--- Day 3 Grade Distribution ---")
day3_dist = df['Day3_Grade'].value_counts().sort_index()
print(day3_dist)

# Day 5 Blastocyst Grade
print("\n--- Day 5 Blastocyst Grade Distribution ---")
day5_dist = df['Day5_Blastocyst_Grade'].value_counts()
print(day5_dist)

# Outcome visualization
fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Fertilization pie chart
axes[0, 0].pie([fert_counts.get(1, 0), fert_counts.get(0, 0)],
               labels=['Success', 'Failure'],
               autopct='%1.1f%%',
               startangle=90,
               colors=['#2E75B5', '#E74C3C'])
axes[0, 0].set_title('Fertilization Success Rate', fontweight='bold', fontsize=12)

# Usable Embryo pie chart
axes[0, 1].pie([embryo_counts.get(1, 0), embryo_counts.get(0, 0)],
               labels=['Usable', 'Not Usable'],
               autopct='%1.1f%%',
               startangle=90,
               colors=['#27AE60', '#E67E22'])
axes[0, 1].set_title('Usable Embryo Rate', fontweight='bold', fontsize=12)

# Day 3 Grade bar chart
if not df['Day3_Grade'].dropna().empty:
    day3_clean = df['Day3_Grade'].dropna()
    axes[1, 0].hist(day3_clean, bins=20, color='#8E44AD', edgecolor='black', alpha=0.7)
    axes[1, 0].set_title('Day 3 Grade Distribution', fontweight='bold', fontsize=12)
    axes[1, 0].set_xlabel('Grade')
    axes[1, 0].set_ylabel('Frequency')
    axes[1, 0].grid(True, alpha=0.3)

# Day 5 Grade bar chart
if not df['Day5_Blastocyst_Grade'].dropna().empty:
    day5_counts = df['Day5_Blastocyst_Grade'].value_counts()
    axes[1, 1].bar(range(len(day5_counts)), day5_counts.values, 
                   color='#16A085', edgecolor='black')
    axes[1, 1].set_xticks(range(len(day5_counts)))
    axes[1, 1].set_xticklabels(day5_counts.index, rotation=45, ha='right')
    axes[1, 1].set_title('Day 5 Blastocyst Grade Distribution', 
                         fontweight='bold', fontsize=12)
    axes[1, 1].set_ylabel('Frequency')
    axes[1, 1].grid(True, axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig('eda_output/plots/04_outcome_analysis.png', dpi=300, bbox_inches='tight')
print("\n✓ Saved: eda_output/plots/04_outcome_analysis.png")


print("\n" + "="*80)
print("SECTION 6: BIVARIATE ANALYSIS")
print("="*80)

# Correlation analysis
print("\n--- Correlation Analysis ---")
corr_cols = [
    'Sperm_Concentration_M_per_ml',
    'Total_Motility_Percent',
    'Progressive_Motility_Percent',
    'Normal_Morphology_Percent',
    'Selection_Time_Seconds',
    'Embryologist_Experience_Years',
    'Lab_Temperature_C',
    'Lab_Humidity_Percent',
    'Cycle_Number',
    'Fertilization_Success',
    'Usable_Embryo'
]

correlation_matrix = df[corr_cols].corr()
print("\nCorrelation Matrix:")
print(correlation_matrix)

# Save correlation matrix
correlation_matrix.to_csv('eda_output/correlation_matrix.csv')

# Correlation heatmap
plt.figure(figsize=(14, 12))
mask = np.triu(np.ones_like(correlation_matrix, dtype=bool))
sns.heatmap(correlation_matrix, 
            mask=mask,
            annot=True, 
            fmt='.2f', 
            cmap='coolwarm',
            center=0,
            square=True,
            linewidths=1,
            cbar_kws={"shrink": 0.8},
            vmin=-1, vmax=1)
plt.title('Correlation Heatmap - Key Variables', fontweight='bold', fontsize=14, pad=20)
plt.tight_layout()
plt.savefig('eda_output/plots/05_correlation_heatmap.png', dpi=300, bbox_inches='tight')
print("\n✓ Saved: eda_output/plots/05_correlation_heatmap.png")

# Sperm quality vs outcomes
print("\n--- Sperm Quality vs Fertilization Success ---")
quality_vars = [
    'Sperm_Concentration_M_per_ml',
    'Total_Motility_Percent',
    'Progressive_Motility_Percent',
    'Normal_Morphology_Percent'
]

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
axes = axes.flatten()

for idx, var in enumerate(quality_vars):
    # Box plot by fertilization success
    success_data = df[df['Fertilization_Success'] == 1][var].dropna()
    failure_data = df[df['Fertilization_Success'] == 0][var].dropna()
    
    bp = axes[idx].boxplot([success_data, failure_data],
                            labels=['Success', 'Failure'],
                            patch_artist=True,
                            widths=0.6)
    
    bp['boxes'][0].set_facecolor('#2E75B5')
    bp['boxes'][1].set_facecolor('#E74C3C')
    
    axes[idx].set_title(f'{var} by Fertilization Outcome', fontweight='bold')
    axes[idx].set_ylabel(var)
    axes[idx].grid(True, alpha=0.3)
    
    # Perform t-test
    t_stat, p_value = stats.ttest_ind(success_data, failure_data)
    sig = "***" if p_value < 0.001 else "**" if p_value < 0.01 else "*" if p_value < 0.05 else "ns"
    
    axes[idx].text(0.5, 0.98, f'p-value: {p_value:.4f} {sig}',
                   transform=axes[idx].transAxes,
                   ha='center', va='top',
                   bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.7))

plt.tight_layout()
plt.savefig('eda_output/plots/06_quality_vs_success.png', dpi=300, bbox_inches='tight')
print("✓ Saved: eda_output/plots/06_quality_vs_success.png")


print("\n" + "="*80)
print("SECTION 7: EMBRYOLOGIST PERFORMANCE ANALYSIS")
print("="*80)

# Performance metrics by embryologist
embryo_perf = df.groupby('Embryologist_ID').agg({
    'Record_ID': 'count',
    'Fertilization_Success': ['sum', 'mean'],
    'Usable_Embryo': ['sum', 'mean'],
    'Selection_Time_Seconds': 'mean',
    'Embryologist_Experience_Years': 'first'
}).round(3)

embryo_perf.columns = ['Total_Procedures', 'Successful_Fert', 'Fert_Rate',
                        'Usable_Embryos', 'Usable_Rate', 'Avg_Time', 'Experience']
embryo_perf = embryo_perf.sort_values('Fert_Rate', ascending=False)

print("\n--- Embryologist Performance Metrics ---")
print(embryo_perf)

embryo_perf.to_csv('eda_output/embryologist_performance.csv')

# Visualize performance
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

# Success rate by embryologist
axes[0, 0].bar(range(len(embryo_perf)), embryo_perf['Fert_Rate'] * 100,
               color='steelblue', edgecolor='black')
axes[0, 0].set_xticks(range(len(embryo_perf)))
axes[0, 0].set_xticklabels(embryo_perf.index, rotation=45, ha='right')
axes[0, 0].set_title('Fertilization Success Rate by Embryologist', fontweight='bold')
axes[0, 0].set_ylabel('Success Rate (%)')
axes[0, 0].axhline(y=fert_rate, color='red', linestyle='--', label='Overall Average')
axes[0, 0].legend()
axes[0, 0].grid(True, axis='y', alpha=0.3)

# Experience vs Success Rate scatter
axes[0, 1].scatter(embryo_perf['Experience'], embryo_perf['Fert_Rate'] * 100,
                   s=embryo_perf['Total_Procedures']*2, alpha=0.6, color='green')
axes[0, 1].set_xlabel('Experience (Years)')
axes[0, 1].set_ylabel('Success Rate (%)')
axes[0, 1].set_title('Experience vs Success Rate (size = procedures)', fontweight='bold')
axes[0, 1].grid(True, alpha=0.3)

# Add trend line
z = np.polyfit(embryo_perf['Experience'], embryo_perf['Fert_Rate'] * 100, 1)
p = np.poly1d(z)
axes[0, 1].plot(embryo_perf['Experience'], p(embryo_perf['Experience']), 
                "r--", alpha=0.8, label=f'Trend')
axes[0, 1].legend()

# Selection time by embryologist
axes[1, 0].bar(range(len(embryo_perf)), embryo_perf['Avg_Time'],
               color='orange', edgecolor='black')
axes[1, 0].set_xticks(range(len(embryo_perf)))
axes[1, 0].set_xticklabels(embryo_perf.index, rotation=45, ha='right')
axes[1, 0].set_title('Average Selection Time by Embryologist', fontweight='bold')
axes[1, 0].set_ylabel('Time (seconds)')
axes[1, 0].grid(True, axis='y', alpha=0.3)

# Procedures count
axes[1, 1].bar(range(len(embryo_perf)), embryo_perf['Total_Procedures'],
               color='purple', edgecolor='black')
axes[1, 1].set_xticks(range(len(embryo_perf)))
axes[1, 1].set_xticklabels(embryo_perf.index, rotation=45, ha='right')
axes[1, 1].set_title('Total Procedures by Embryologist', fontweight='bold')
axes[1, 1].set_ylabel('Number of Procedures')
axes[1, 1].grid(True, axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig('eda_output/plots/07_embryologist_performance.png', dpi=300, bbox_inches='tight')
print("✓ Saved: eda_output/plots/07_embryologist_performance.png")


print("\n" + "="*80)
print("SECTION 8: TEMPORAL ANALYSIS")
print("="*80)

# Extract temporal features
df['Year'] = df['Selection_Date'].dt.year
df['Month'] = df['Selection_Date'].dt.month
df['Quarter'] = df['Selection_Date'].dt.quarter
df['DayOfWeek'] = df['Selection_Date'].dt.dayofweek
df['WeekOfYear'] = df['Selection_Date'].dt.isocalendar().week

# Monthly trends
monthly_trends = df.groupby(['Year', 'Month']).agg({
    'Record_ID': 'count',
    'Fertilization_Success': 'mean',
    'Usable_Embryo': 'mean',
    'Selection_Time_Seconds': 'mean'
}).round(3)

monthly_trends.columns = ['Procedures', 'Fert_Rate', 'Usable_Rate', 'Avg_Time']
print("\n--- Monthly Trends ---")
print(monthly_trends)

monthly_trends.to_csv('eda_output/monthly_trends.csv')

# Visualize temporal patterns
fig, axes = plt.subplots(2, 2, figsize=(16, 10))

# Procedures over time
df_sorted = df.sort_values('Selection_Date')
monthly_counts = df.groupby(df['Selection_Date'].dt.to_period('M')).size()
axes[0, 0].plot(monthly_counts.index.astype(str), monthly_counts.values, 
                marker='o', linewidth=2, markersize=6)
axes[0, 0].set_title('Procedures Over Time', fontweight='bold')
axes[0, 0].set_xlabel('Month')
axes[0, 0].set_ylabel('Number of Procedures')
axes[0, 0].tick_params(axis='x', rotation=45)
axes[0, 0].grid(True, alpha=0.3)

# Success rate over time
monthly_success = df.groupby(df['Selection_Date'].dt.to_period('M'))['Fertilization_Success'].mean() * 100
axes[0, 1].plot(monthly_success.index.astype(str), monthly_success.values,
                marker='s', linewidth=2, markersize=6, color='green')
axes[0, 1].set_title('Success Rate Over Time', fontweight='bold')
axes[0, 1].set_xlabel('Month')
axes[0, 1].set_ylabel('Success Rate (%)')
axes[0, 1].tick_params(axis='x', rotation=45)
axes[0, 1].axhline(y=fert_rate, color='red', linestyle='--', label='Overall Average')
axes[0, 1].legend()
axes[0, 1].grid(True, alpha=0.3)

# Day of week analysis
dow_success = df.groupby('DayOfWeek')['Fertilization_Success'].mean() * 100
dow_labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
axes[1, 0].bar(range(7), [dow_success.get(i, 0) for i in range(7)],
               color='coral', edgecolor='black')
axes[1, 0].set_xticks(range(7))
axes[1, 0].set_xticklabels(dow_labels)
axes[1, 0].set_title('Success Rate by Day of Week', fontweight='bold')
axes[1, 0].set_ylabel('Success Rate (%)')
axes[1, 0].axhline(y=fert_rate, color='red', linestyle='--')
axes[1, 0].grid(True, axis='y', alpha=0.3)

# Quarterly comparison
quarterly = df.groupby('Quarter')['Fertilization_Success'].mean() * 100
axes[1, 1].bar(['Q1', 'Q2', 'Q3', 'Q4'], 
               [quarterly.get(i, 0) for i in range(1, 5)],
               color='teal', edgecolor='black')
axes[1, 1].set_title('Success Rate by Quarter', fontweight='bold')
axes[1, 1].set_ylabel('Success Rate (%)')
axes[1, 1].axhline(y=fert_rate, color='red', linestyle='--')
axes[1, 1].grid(True, axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig('eda_output/plots/08_temporal_analysis.png', dpi=300, bbox_inches='tight')
print("✓ Saved: eda_output/plots/08_temporal_analysis.png")


print("\n" + "="*80)
print("SECTION 9: MORPHOLOGICAL ASSESSMENT ANALYSIS")
print("="*80)

# Success rate by morphological features
morpho_features = [
    'Head_Shape_Score',
    'Acrosome_Status',
    'Midpiece_Assessment',
    'Tail_Assessment',
    'Motility_Pattern'
]

fig, axes = plt.subplots(2, 3, figsize=(18, 10))
axes = axes.flatten()

for idx, feature in enumerate(morpho_features):
    if idx < len(axes):
        # Success rate by category
        success_by_cat = df.groupby(feature)['Fertilization_Success'].agg(['mean', 'count'])
        success_by_cat = success_by_cat[success_by_cat['count'] >= 5]  # Filter small groups
        success_by_cat['mean'] = success_by_cat['mean'] * 100
        
        if not success_by_cat.empty:
            axes[idx].bar(range(len(success_by_cat)), success_by_cat['mean'],
                         color='skyblue', edgecolor='black')
            axes[idx].set_xticks(range(len(success_by_cat)))
            axes[idx].set_xticklabels(success_by_cat.index, rotation=45, ha='right')
            axes[idx].set_title(f'Success Rate by {feature}', fontweight='bold')
            axes[idx].set_ylabel('Success Rate (%)')
            axes[idx].axhline(y=fert_rate, color='red', linestyle='--', alpha=0.7)
            axes[idx].grid(True, axis='y', alpha=0.3)
            
            # Add sample size labels
            for i, (idx_val, row) in enumerate(success_by_cat.iterrows()):
                axes[idx].text(i, row['mean'] + 1, f"n={int(row['count'])}", 
                              ha='center', fontsize=8)

# Remove extra subplots
for idx in range(len(morpho_features), len(axes)):
    fig.delaxes(axes[idx])

plt.tight_layout()
plt.savefig('eda_output/plots/09_morphological_analysis.png', dpi=300, bbox_inches='tight')
print("✓ Saved: eda_output/plots/09_morphological_analysis.png")


print("\n" + "="*80)
print("SECTION 10: LAB CONDITIONS ANALYSIS")
print("="*80)

# Define optimal ranges
df['Temp_Optimal'] = df['Lab_Temperature_C'].between(36.5, 37.5)
df['Humidity_Optimal'] = df['Lab_Humidity_Percent'].between(40, 60)
df['Lab_Conditions_Optimal'] = df['Temp_Optimal'] & df['Humidity_Optimal']

# Analysis by conditions
print("\n--- Success Rate by Lab Conditions ---")
lab_analysis = df.groupby('Lab_Conditions_Optimal')['Fertilization_Success'].agg(['mean', 'count'])
lab_analysis['mean'] = lab_analysis['mean'] * 100
print(lab_analysis)

# Visualize
fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Temperature vs Success
temp_bins = pd.cut(df['Lab_Temperature_C'], bins=10)
temp_success = df.groupby(temp_bins)['Fertilization_Success'].mean() * 100
axes[0, 0].plot(range(len(temp_success)), temp_success.values, 
                marker='o', linewidth=2, color='red')
axes[0, 0].set_title('Success Rate by Temperature Range', fontweight='bold')
axes[0, 0].set_xlabel('Temperature Range')
axes[0, 0].set_ylabel('Success Rate (%)')
axes[0, 0].tick_params(axis='x', rotation=45)
axes[0, 0].grid(True, alpha=0.3)

# Humidity vs Success
humidity_bins = pd.cut(df['Lab_Humidity_Percent'], bins=10)
humidity_success = df.groupby(humidity_bins)['Fertilization_Success'].mean() * 100
axes[0, 1].plot(range(len(humidity_success)), humidity_success.values,
                marker='s', linewidth=2, color='blue')
axes[0, 1].set_title('Success Rate by Humidity Range', fontweight='bold')
axes[0, 1].set_xlabel('Humidity Range')
axes[0, 1].set_ylabel('Success Rate (%)')
axes[0, 1].tick_params(axis='x', rotation=45)
axes[0, 1].grid(True, alpha=0.3)

# Optimal vs Suboptimal
lab_comp = df.groupby('Lab_Conditions_Optimal')['Fertilization_Success'].mean() * 100
axes[1, 0].bar(['Suboptimal', 'Optimal'], [lab_comp.get(False, 0), lab_comp.get(True, 0)],
               color=['#E74C3C', '#27AE60'], edgecolor='black')
axes[1, 0].set_title('Success Rate: Optimal vs Suboptimal Conditions', fontweight='bold')
axes[1, 0].set_ylabel('Success Rate (%)')
axes[1, 0].grid(True, axis='y', alpha=0.3)

# Equipment comparison
equip_success = df.groupby('Microscope_Type')['Fertilization_Success'].agg(['mean', 'count'])
equip_success['mean'] = equip_success['mean'] * 100
equip_success = equip_success[equip_success['count'] >= 10]
axes[1, 1].bar(range(len(equip_success)), equip_success['mean'],
               color='purple', edgecolor='black')
axes[1, 1].set_xticks(range(len(equip_success)))
axes[1, 1].set_xticklabels(equip_success.index, rotation=45, ha='right')
axes[1, 1].set_title('Success Rate by Microscope Type', fontweight='bold')
axes[1, 1].set_ylabel('Success Rate (%)')
axes[1, 1].grid(True, axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig('eda_output/plots/10_lab_conditions.png', dpi=300, bbox_inches='tight')
print("✓ Saved: eda_output/plots/10_lab_conditions.png")


print("\n" + "="*80)
print("SECTION 11: PATIENT CYCLE ANALYSIS")
print("="*80)

# Analysis by cycle number
cycle_analysis = df.groupby('Cycle_Number').agg({
    'Record_ID': 'count',
    'Fertilization_Success': 'mean',
    'Usable_Embryo': 'mean',
    'Selection_Time_Seconds': 'mean'
}).round(3)

cycle_analysis.columns = ['Total_Procedures', 'Fert_Rate', 'Usable_Rate', 'Avg_Time']
print("\n--- Analysis by Cycle Number ---")
print(cycle_analysis)

# Visualize
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Success rate by cycle
axes[0].plot(cycle_analysis.index, cycle_analysis['Fert_Rate'] * 100,
             marker='o', linewidth=2, markersize=8, color='darkgreen')
axes[0].set_title('Success Rate by Cycle Number', fontweight='bold')
axes[0].set_xlabel('Cycle Number')
axes[0].set_ylabel('Success Rate (%)')
axes[0].grid(True, alpha=0.3)

# Procedures per cycle
axes[1].bar(cycle_analysis.index, cycle_analysis['Total_Procedures'],
            color='teal', edgecolor='black')
axes[1].set_title('Number of Procedures by Cycle', fontweight='bold')
axes[1].set_xlabel('Cycle Number')
axes[1].set_ylabel('Number of Procedures')
axes[1].grid(True, axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig('eda_output/plots/11_cycle_analysis.png', dpi=300, bbox_inches='tight')
print("✓ Saved: eda_output/plots/11_cycle_analysis.png")


print("\n" + "="*80)
print("SECTION 12: KEY INSIGHTS SUMMARY")
print("="*80)

insights = {
    'Total Records': len(df),
    'Date Range': f"{df['Selection_Date'].min()} to {df['Selection_Date'].max()}",
    'Overall Fertilization Rate (%)': round(fert_rate, 2),
    'Usable Embryo Rate (%)': round(embryo_rate, 2),
    'Average Selection Time (sec)': round(df['Selection_Time_Seconds'].mean(), 2),
    'Unique Patients': df['Patient_ID'].nunique(),
    'Unique Embryologists': df['Embryologist_ID'].nunique(),
    'Avg Sperm Concentration (M/ml)': round(df['Sperm_Concentration_M_per_ml'].mean(), 2),
    'Avg Total Motility (%)': round(df['Total_Motility_Percent'].mean(), 2),
    'Avg Progressive Motility (%)': round(df['Progressive_Motility_Percent'].mean(), 2),
    'Avg Normal Morphology (%)': round(df['Normal_Morphology_Percent'].mean(), 2),
    'Optimal Lab Conditions (%)': round((df['Lab_Conditions_Optimal'].sum() / len(df)) * 100, 2),
    'Top Performing Embryologist': embryo_perf.index[0],
    'Top Embryologist Success Rate (%)': round(embryo_perf.iloc[0]['Fert_Rate'] * 100, 2),
    'Correlation (Experience vs Success)': round(correlation_matrix.loc['Embryologist_Experience_Years', 'Fertilization_Success'], 3),
    'Correlation (Motility vs Success)': round(correlation_matrix.loc['Total_Motility_Percent', 'Fertilization_Success'], 3),
}

insights_df = pd.DataFrame([insights]).T
insights_df.columns = ['Value']
print("\n--- Key Insights ---")
print(insights_df)

insights_df.to_csv('eda_output/key_insights_summary.csv')

print("\n" + "="*80)
print("EDA COMPLETED SUCCESSFULLY!")
print("="*80)

print("\n📁 Output Files Generated:")
print("   1. eda_output/data_quality_report.csv")
print("   2. eda_output/descriptive_statistics.csv")
print("   3. eda_output/correlation_matrix.csv")
print("   4. eda_output/embryologist_performance.csv")
print("   5. eda_output/monthly_trends.csv")
print("   6. eda_output/key_insights_summary.csv")

print("\n📊 Visualizations Created:")
for i in range(1, 12):
    print(f"   {i:2d}. eda_output/plots/{i:02d}_*.png")

print("\n✨ Next Steps:")
print("   1. Review all generated plots and tables")
print("   2. Investigate key findings and outliers")
print("   3. Proceed with data preprocessing and feature engineering")
print("   4. Conduct statistical hypothesis testing")
print("   5. Build predictive models")


